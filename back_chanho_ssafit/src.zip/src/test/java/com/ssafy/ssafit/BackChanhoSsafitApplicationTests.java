package com.ssafy.ssafit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackChanhoSsafitApplicationTests {

	@Test
	void contextLoads() {
	}

}


SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

CREATE SCHEMA IF NOT EXISTS `ssafit` DEFAULT CHARACTER SET utf8 ;
-- -----------------------------------------------------
-- Schema new_schema1
-- -----------------------------------------------------
USE `ssafit` ;

-- -----------------------------------------------------
-- Table `ssafit`.`User`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssafit`.`User` (
  `id` VARCHAR(30) NOT NULL,
  `password` VARCHAR(500) NOT NULL,
  `name` VARCHAR(30) NOT NULL,
  `email` VARCHAR(50) NOT NULL,
  `isAdmin` TINYINT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ssafit`.`Video`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssafit`.`Video` (
  `title` VARCHAR(100) NOT NULL,
  `part` VARCHAR(45) NOT NULL,
  `youtubeId` VARCHAR(100) NOT NULL,
  `channelName` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`title`))
ENGINE = InnoDB;


CREATE TABLE IF NOT EXISTS `ssafit`.`Friend` (
  `friendId` INT NOT NULL AUTO_INCREMENT,
  `userId` VARCHAR(30) NOT NULL,
  `friendUserId` VARCHAR(30) NOT NULL,
  `isAccept` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`friendId`),
  INDEX `userId_idx` (`userId` ASC) VISIBLE,
  INDEX `frienduserId_idx` (`friendUserId` ASC) VISIBLE,
  CONSTRAINT `fk_userId`
    FOREIGN KEY (`userId`)
    REFERENCES `ssafit`.`User` (`id`)
    ON DELETE Cascade
    ON UPDATE Cascade,
  CONSTRAINT `fk_frienduserId`
    FOREIGN KEY (`friendUserId`)
    REFERENCES `ssafit`.`User` (`id`)
    ON DELETE Cascade
    ON UPDATE Cascade)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ssafit`.`Diary`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssafit`.`Diary` (
  `diaryId` INT NOT NULL AUTO_INCREMENT,
  `part` VARCHAR(10) NOT NULL,
  `userId` VARCHAR(30) NOT NULL,
  `weight` INT NOT NULL,
  `reps` INT NOT NULL,
  `set` INT NOT NULL,
  `updateDate` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP(),
  `date` DATETIME NOT NULL,
  `isDone` INT NOT NULL,
  PRIMARY KEY (`diaryId`),
  INDEX `userId_idx` (`userId` ASC) VISIBLE,
  CONSTRAINT `fk_diary_userId`
    FOREIGN KEY (`userId`)
    REFERENCES `ssafit`.`User` (`id`)
    ON DELETE Cascade
    ON UPDATE Cascade)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ssafit`.`Alarm`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssafit`.`Alarm` (
  `alarmId` INT NOT NULL AUTO_INCREMENT,
  `userId` VARCHAR(30) NOT NULL,
  `alarmDate` DATETIME NOT NULL,
  `diaryId` INT NULL,
  `friendId` INT NULL,
  `type` TINYINT NULL,
  `isCheck` TINYINT NULL,
  PRIMARY KEY (`alarmId`),
  INDEX `fk_alarm_userId_idx` (`userId` ASC) VISIBLE,
  INDEX `fk_diaryId_idx` (`diaryId` ASC) VISIBLE,
  INDEX `fk_friendId_idx` (`friendId` ASC) VISIBLE,
  CONSTRAINT `fk_alarm_userId`
    FOREIGN KEY (`userId`)
    REFERENCES `ssafit`.`User` (`id`)
    ON DELETE Cascade
    ON UPDATE Cascade,
  CONSTRAINT `fk_diaryId`
    FOREIGN KEY (`diaryId`)
    REFERENCES `ssafit`.`Diary` (`diaryId`)
    ON DELETE Cascade
    ON UPDATE Cascade,
  CONSTRAINT `fk_friendId`
    FOREIGN KEY (`friendId`)
    REFERENCES `ssafit`.`Friend` (`friendId`)
    ON DELETE Cascade
    ON UPDATE Cascade)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
